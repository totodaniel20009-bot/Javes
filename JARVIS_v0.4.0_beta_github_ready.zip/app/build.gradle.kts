plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "dev.personal.jarvis"
    compileSdk = 35
    defaultConfig {
        // Separate app ID: GitHub Actions' ephemeral debug signing key
        // cannot update the earlier v0.3.0 installation in place.
        applicationId = "dev.personal.jarvis.ai"
        minSdk = 30
        targetSdk = 35
        versionCode = 2
        versionName = "0.4.0-beta"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.18.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.10.2")
}
