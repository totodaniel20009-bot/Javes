package dev.personal.jarvis

import android.app.Activity
import android.content.Intent
import android.database.Cursor
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.nio.file.AtomicMoveNotSupportedException
import java.util.concurrent.Executors

/** Setup screen. The accessibility overlay is the agent's actual control UI. */
class MainActivity : Activity() {
    private val importWorker = Executors.newSingleThreadExecutor()
    private lateinit var modelInfo: TextView
    private lateinit var pickButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
            setBackgroundColor(Color.rgb(18, 20, 27))
        }
        fun txt(value: String, size: Float): TextView = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(15))
        }
        page.addView(txt("JARVIS 0.4.0-beta", 24f))
        page.addView(txt("오프라인 로컬 AI + 화면 읽기 + 8단계 제한 자동 조작 시험판", 15f))
        modelInfo = txt("모델 확인 중", 14f)
        page.addView(modelInfo)
        refreshModelStatus()

        pickButton = Button(this).apply {
            text = "① .litertlm 모델 가져오기"
            setOnClickListener {
                val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(picker, PICK_MODEL)
            }
        }
        page.addView(pickButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, -2))
        page.addView(txt("기존 0.2.1에서 사용한 gemma3-1b-it-int4.litertlm 파일을 선택할 수 있어요. 모델은 APK에 포함하지 않으며 기기 내부 저장소로 복사됩니다.", 13f))

        val perm = Button(this).apply {
            text = "② 접근성 설정 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        page.addView(perm, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, -2))
        page.addView(txt("③ 기존 0.3.0 접근성 서비스를 끄고, 이 앱의 JARVIS 접근성 서비스를 켭니다.\n④ 설정 같은 테스트 앱을 연 다음 오른쪽의 J 버튼을 누릅니다.\n⑤ 목표를 입력하고 'AI 작업 시작'을 누릅니다.\n⑥ 상단의 붉은 '■ 중지'로 즉시 중지할 수 있습니다.", 15f))

        page.addView(txt("명령 시험 예시\n• '화면 읽어' → 기존 규칙 기반 화면 읽기\n• '설정 열어' → 기존 규칙 기반 앱 실행\n• '디스플레이에서 다크 모드 찾아줘' → AI 작업 시작 버튼\n\nAI는 현재 열려 있는 앱의 접근성 텍스트만 분석합니다. 스크린샷 비전 AI, 음성, 클라우드 연결은 아직 없습니다. 중요한 조작에는 승인 화면이 나타납니다.", 14f))
        page.addView(txt("주의: 로컬 모델이 잘못된 버튼을 고를 수 있어요. 금융·인증·결제 앱에서는 자동 조작을 사용하지 마세요. 초반에는 설정·계산기 같은 안전한 화면에서 테스트하세요. 네트워크 권한이 없어 화면 내용은 외부로 전송하지 않습니다.", 13f))
        val scroll = ScrollView(this)
        scroll.addView(page)
        setContentView(scroll)
    }

    private fun refreshModelStatus() {
        val file = LocalModelController.modelFile(this)
        modelInfo.text = if (LocalModelController.hasModel(this)) {
            "로컬 모델: 준비됨 (${file.length() / 1024 / 1024}MB)"
        } else "로컬 모델: 없음 — .litertlm 파일을 가져와 주세요"
    }

    @Deprecated("Android's document picker callback for a simple Activity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_MODEL || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val name = displayName(uri)
        if (!name.endsWith(".litertlm", ignoreCase = true)) {
            modelInfo.text = ".litertlm 확장자 모델 파일을 선택하세요."
            return
        }
        pickButton.isEnabled = false
        modelInfo.text = "모델을 내부 저장소로 복사하는 중… 앱을 종료하지 마세요."
        importWorker.execute {
            val target = LocalModelController.modelFile(this)
            val part = java.io.File(target.absolutePath + ".partial")
            val result = runCatching {
                contentResolver.openInputStream(uri).use { source ->
                    requireNotNull(source) { "파일을 열 수 없습니다." }
                    FileOutputStream(part).use { dest -> source.copyTo(dest, 512 * 1024) }
                }
                require(part.length() > 1_000_000L) { "모델 파일이 너무 작거나 불완전합니다." }
                // Replace only after complete copy; retain the prior model on failed imports.
                try {
                    Files.move(part.toPath(), target.toPath(),
                        StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
                } catch (_: AtomicMoveNotSupportedException) {
                    Files.move(part.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
                }
                "모델 가져오기 성공. 이미 AI가 실행 중이라면 접근성을 껐다 켠 뒤 사용하세요."
            }
            if (result.isFailure) part.delete()
            runOnUiThread {
                pickButton.isEnabled = true
                modelInfo.text = result.getOrElse { "모델 복사 실패: ${it.message}" }
            }
        }
    }

    private fun displayName(uri: Uri): String {
        return runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c: Cursor ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull() ?: uri.lastPathSegment.orEmpty()
    }

    override fun onDestroy() {
        importWorker.shutdown()
        super.onDestroy()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    companion object { private const val PICK_MODEL = 71 }
}
