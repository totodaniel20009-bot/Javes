plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "dev.personal.jarvis"
    compileSdk = 35
    defaultConfig {
        // Separate app ID because GitHub Actions ephemeral debug signing keys differ
        // between runs. Prevents signature clashes with 0.4.0 installations.
        applicationId = "dev.personal.jarvis.ai.fix041"
        minSdk = 30
        targetSdk = 35
        versionCode = 3
        versionName = "0.4.1-beta"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.18.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.10.2")
}
