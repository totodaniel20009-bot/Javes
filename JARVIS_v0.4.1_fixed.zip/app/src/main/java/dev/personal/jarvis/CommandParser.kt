package dev.personal.jarvis

/** Strict deterministic command parser. NO model is integrated in this version. */
sealed interface Command {
    data object ScreenRead : Command
    data object Back : Command
    data object Home : Command
    data object ScrollDown : Command
    data object ScrollUp : Command
    data class OpenApp(val name: String) : Command
    data class Click(val label: String) : Command
    data class Find(val label: String) : Command
    data class Unsupported(val reason: String) : Command
}

object CommandParser {
    fun parse(raw: String): Command {
        val t = raw.trim().replace(Regex("\\s+"), " ")
        if (t.isBlank()) return Command.Unsupported("명령을 입력하세요")
        if (t == "뒤로" || t == "뒤로 가" || t == "뒤로 가기") return Command.Back
        if (t == "홈" || t == "홈으로" || t == "홈으로 가") return Command.Home
        if (t == "아래로" || t == "아래로 스크롤") return Command.ScrollDown
        if (t == "위로" || t == "위로 스크롤") return Command.ScrollUp
        if (t in listOf("화면 읽어", "화면 읽어줘", "화면 분석", "현재 화면", "뭐 보여")) return Command.ScreenRead
        val click = Regex("^(.+?)\\s*(?:눌러줘|눌러|클릭해줘|클릭해)$").matchEntire(t)
        if (click != null) return Command.Click(click.groupValues[1].trim())
        val find = Regex("^(.+?)\\s*(?:찾아줘|찾아)$").matchEntire(t)
        if (find != null) return Command.Find(find.groupValues[1].trim())
        val open = Regex("^(.+?)\\s*(?:열어줘|열어|실행해줘|실행해)$").matchEntire(t)
        if (open != null) return Command.OpenApp(open.groupValues[1].trim())
        return Command.Unsupported("아직 지원하지 않는 명령입니다. 현재는 화면 읽기·앱 실행·버튼 클릭·스크롤·뒤로/홈 이동을 지원합니다.")
    }
}

object RiskPolicy {
    // Only "obviously safe" operations are automatic. Otherwise confirm.
    private val sensitive = listOf(
        "삭제", "지우", "초기화", "결제", "구매", "송금", "이체", "출금", "주문", "결제하기",
        "제출", "전송", "보내기", "공유", "발행", "게시", "업로드", "로그아웃", "계정 삭제",
        "권한", "허용", "개인정보", "통화", "전화걸기", "구독", "해지", "탈퇴", "차단",
        "인증", "보안", "공장 초기화", "저장", "확인", "완료"
    )
    private val forbidden = listOf("비밀번호", "패스워드", "OTP", "인증번호", "PIN 입력", "보안코드")

    fun isForbidden(text: String) = forbidden.any { text.contains(it, ignoreCase = true) }
    fun needsConfirmation(text: String) = sensitive.any { text.contains(it, ignoreCase = true) }
}
