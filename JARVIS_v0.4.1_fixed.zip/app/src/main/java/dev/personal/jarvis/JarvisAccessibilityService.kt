package dev.personal.jarvis

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * User-triggered, offline local-model screen agent.
 * Only accessibility text nodes (not screenshots) are interpreted in this version.
 * All model actions are checked before they can execute.
 */
class JarvisAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var windowManager: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var stopBubble: View? = null
    private var aiActive = false
    private var input: EditText? = null
    private var draft = ""
    private var result = "대기 중. 화면을 읽거나 간단한 명령을 입력하세요."
    private var sessionId = 0
    private var pendingApproval: (() -> Unit)? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No background recording or automatic actions.
    }

    override fun onInterrupt() { stopCurrentTask() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    override fun onDestroy() {
        stopCurrentTask()
        removePanel()
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }

    private fun dp(px: Int) = (px * resources.displayMetrics.density).toInt()
    private fun overlayParams(width: Int, height: Int, gravity: Int, focusable: Boolean) =
        WindowManager.LayoutParams(
            width, height, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                (if (focusable) 0 else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE),
            PixelFormat.TRANSLUCENT
        ).apply {
            this.gravity = gravity
            if (focusable) softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

    private fun showBubble() {
        if (bubble != null) return
        val b = Button(this).apply {
            text = "J"
            textSize = 17f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(50, 80, 118))
            setOnClickListener {
                if (panel != null) removePanel()
                else {
                    if (aiActive) stopCurrentTask()
                    showPanel(result)
                }
            }
        }
        val p = overlayParams(dp(54), dp(54), Gravity.TOP or Gravity.END, false)
        p.x = dp(12)
        p.y = dp(110)
        try {
            windowManager.addView(b, p)
            bubble = b
        } catch (e: Exception) {
            result = "오버레이를 표시할 수 없습니다: ${e.message}"
        }
    }

    private fun uiText(value: String, size: Float = 14f): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(Color.WHITE)
        setPadding(dp(5), dp(8), dp(5), dp(8))
    }

    private fun showPanel(message: String = result) {
        removePanel()
        result = message
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.rgb(26, 30, 40))
        }
        root.addView(uiText("JARVIS 0.4.1 • 로컬 화면 AI", 17f))
        root.addView(uiText("AI 작업은 현재 열린 앱을 관찰하면서 단계별로 실행합니다.", 12f))
        val editor = EditText(this).apply {
            setSingleLine(true)
            hint = "예: 디스플레이에서 다크 모드 찾아줘"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            setText(draft)
            setSelectAllOnFocus(false)
        }
        input = editor
        root.addView(editor)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun makeButton(label: String, handlerAction: () -> Unit) {
            val b = Button(this).apply {
                text = label
                textSize = 12f
                setOnClickListener { handlerAction() }
            }
            actions.addView(b, LinearLayout.LayoutParams(0, dp(51), 1f))
        }
        makeButton("실행") {
            draft = editor.text.toString()
            submit(draft)
        }
        makeButton("화면 읽기") {
            draft = editor.text.toString()
            submit("화면 읽어")
        }
        makeButton("중지") {
            stopCurrentTask()
            showPanel("작업을 중지했습니다.")
        }
        root.addView(actions)
        val footer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val close = Button(this).apply {
            text = "닫기"
            setOnClickListener { draft = editor.text.toString(); removePanel() }
        }
        val ai = Button(this).apply {
            text = "AI 작업 시작"
            setOnClickListener {
                draft = editor.text.toString()
                startAiTask(draft)
            }
        }
        footer.addView(ai, LinearLayout.LayoutParams(0, -2, 1f))
        footer.addView(close, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(footer)
        val output = uiText(message, 13f)
        val scroller = ScrollView(this)
        scroller.addView(output)
        root.addView(scroller, LinearLayout.LayoutParams(-1, dp(250)))
        val maxWidth = resources.displayMetrics.widthPixels - dp(24)
        val p = overlayParams(minOf(dp(355), maxWidth), WindowManager.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL, true)
        p.y = dp(72)
        try {
            windowManager.addView(root, p)
            panel = root
        } catch (e: Exception) { result = "패널 표시 실패: ${e.message}" }
    }

    private fun removePanel() {
        input?.let { edit ->
            try {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(edit.windowToken, 0)
            } catch (_: Exception) {}
        }
        input = null
        panel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    private fun stopCurrentTask() {
        sessionId++
        aiActive = false
        pendingApproval = null
        hideStopBubble()
    }

    private fun showStopBubble() {
        if (stopBubble != null) return
        val b = Button(this).apply {
            text = "■ 중지"
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(140, 35, 35))
            setOnClickListener {
                stopCurrentTask()
                showPanel("사용자가 AI 작업을 중지했습니다. 진행 중인 모델 추론 결과는 실행하지 않습니다.")
            }
        }
        val p = overlayParams(dp(85), dp(52), Gravity.TOP or Gravity.END, false)
        p.x = dp(12)
        p.y = dp(174)
        try { windowManager.addView(b, p); stopBubble = b }
        catch (_: Exception) { stopCurrentTask(); showPanel("긴급 중지 버튼을 표시하지 못해 AI 작업을 중단했습니다.") }
    }

    private fun hideStopBubble() {
        stopBubble?.let { if (::windowManager.isInitialized) try { windowManager.removeView(it) } catch (_: Exception) {} }
        stopBubble = null
    }

    private fun finishAi(token: Int, text: String) {
        if (token != sessionId) return
        stopCurrentTask()
        showPanel(text)
    }

    private fun startAiTask(goal: String) {
        stopCurrentTask()
        if (goal.isBlank()) { showPanel("AI에게 수행할 목표를 입력해 주세요."); return }
        if (!LocalModelController.hasModel(this)) {
            showPanel("로컬 모델이 아직 없습니다. JARVIS 앱을 열고 .litertlm 모델 파일을 가져오세요.")
            return
        }
        result = "AI가 화면을 분석하는 중: ${goal.take(70)}"
        removePanel()
        aiActive = true
        showStopBubble()
        val token = sessionId
        handler.postDelayed({ aiNext(token, goal.take(180), 0, "시작", "", "") }, 600)
    }

    private fun aiNext(token: Int, goal: String, stepNo: Int, previous: String, lastFingerprint: String, originPackage: String) {
        if (token != sessionId || !aiActive) return
        if (stepNo >= 8) {
            finishAi(token, "최대 8단계에 도달하여 작업을 중단했습니다. 목표를 확인해 주세요.")
            return
        }
        val snapshot = ScreenObserver.inspect(rootInActiveWindow)
        if (snapshot.appPackage.isEmpty() || snapshot.appPackage == packageName) {
            finishAi(token, "다른 앱의 화면을 읽을 수 없습니다. 목표 앱을 연 뒤 다시 실행하세요.")
            return
        }
        if (originPackage.isNotBlank() && snapshot.appPackage != originPackage) {
            finishAi(token, "작업 대상 앱이 바뀌어 자동 실행을 중단했습니다.")
            return
        }
        if (isSensitivePackage(snapshot.appPackage)) {
            finishAi(token, "금융·인증 등 민감한 앱에서는 AI 자동 조작을 허용하지 않습니다.")
            return
        }
        if (snapshot.items.isEmpty()) {
            finishAi(token, "현재 화면에 읽을 수 있는 접근성 요소가 없습니다. 직접 조작해 주세요.")
            return
        }
        if (snapshot.items.any { RiskPolicy.isForbidden(it.label) }) {
            finishAi(token, "인증 정보가 포함된 화면에서는 AI 자동 조작을 중단합니다.")
            return
        }
        val fp = snapshot.fingerprint()
        if (stepNo > 0 && fp == lastFingerprint) {
            finishAi(token, "이전 조작 뒤 화면 변화가 확인되지 않아 멈췄습니다. 다시 확인해 주세요.")
            return
        }
        result = "AI 판단 중 (${stepNo + 1}/8): ${goal.take(60)}"
        // A small local model may produce a parseable object with an invalid index.
        // Diagnose the exact reason, ask for ONE corrected proposal, then stop if still invalid.
        fun checkProposal(resultValue: Result<String>, retried: Boolean) {
            if (token != sessionId || !aiActive) return
            val raw = resultValue.getOrElse {
                finishAi(token, "로컬 모델 오류: ${it.javaClass.simpleName}: ${it.message.orEmpty().take(120)}")
                return
            }
            when (val verdict = AiActionProtocol.validate(raw, snapshot)) {
                is AiValidation.Accepted -> aiExecute(token, goal, stepNo, snapshot, verdict.proposal, fp)
                is AiValidation.Rejected -> {
                    if (retried) {
                        finishAi(token, "AI 제안을 두 번 검증했지만 실행할 수 없어 중단했습니다. " +
                            "사유: ${verdict.detail} / 최근 응답: ${raw.take(130)}")
                    } else {
                        result = "잘못된 AI 제안(${verdict.detail.take(80)})을 수정 요청 중"
                        LocalModelController.analyze(
                            this, AiActionProtocol.retryPrompt(goal, snapshot, stepNo + 1, previous, verdict.detail)
                        ) { second -> checkProposal(second, true) }
                    }
                }
            }
        }
        LocalModelController.analyze(this, AiActionProtocol.buildPrompt(goal, snapshot, stepNo + 1, previous)) {
            checkProposal(it, false)
        }
    }

    private fun aiExecute(token: Int, goal: String, stepNo: Int,
                          snapshot: ScreenSnapshot, proposal: AiProposal, fp: String) {
        if (token != sessionId || !aiActive) return
        // Do not execute a stale model decision after the user or an app changed the screen.
        val freshSnapshot = ScreenObserver.inspect(rootInActiveWindow)
        if (freshSnapshot.appPackage != snapshot.appPackage || freshSnapshot.fingerprint() != fp) {
            finishAi(token, "AI가 판단하는 동안 화면이 바뀌었습니다. 재확인 후 다시 시작하세요.")
            return
        }
        val step = proposal.step
        when (step) {
            is AiStep.Stop -> finishAi(token, "AI가 더 진행하기 어렵다고 판단해 중단했습니다. ${proposal.reason}")
            is AiStep.Done -> {
                // The model's own 'done' is not considered proof of completion.
                val tokens = goal.lowercase().split(Regex("[^가-힣a-z0-9]+"))
                    .filter { it.length >= 2 && it !in setOf("찾아줘", "해줘", "보여줘", "열어줘", "들어가", "설정에서", "화면에서") }
                val verified = tokens.any { term -> snapshot.items.any { it.label.lowercase().contains(term) } }
                finishAi(token, if (verified) "AI가 작업 완료를 제안했고 목표 관련 항목이 화면에서 확인되었습니다. 실제 설정은 직접 확인해 주세요."
                    else "AI가 완료라고 응답했지만 목표를 화면에서 검증할 수 없어 중단했습니다.")
            }
            is AiStep.Click -> {
                val item = snapshot.items.getOrNull(step.index) ?: run {
                    finishAi(token, "AI가 존재하지 않는 항목을 선택했습니다."); return
                }
                if (RiskPolicy.isForbidden(item.label)) {
                    finishAi(token, "인증·보안 입력과 관련된 화면은 AI가 조작하지 않습니다.")
                    return
                }
                val clickAction = {
                    // Approval overlay must be gone. Check the exact package, label and coordinates again.
                    if (sessionId == token && aiActive) {
                        val fresh = ScreenObserver.inspect(rootInActiveWindow)
                        if (fresh.appPackage != snapshot.appPackage) {
                            finishAi(token, "화면 앱이 바뀌어 클릭을 취소했습니다.")
                        } else {
                            val freshItem = fresh.items.getOrNull(step.index)
                            if (freshItem == null || freshItem != item) {
                                finishAi(token, "클릭 대상의 내용이나 위치가 바뀌어 중단했습니다.")
                            } else {
                                val target = ScreenObserver.resolveTarget(rootInActiveWindow, item)
                                val clicked = target != null && performNodeClick(target)
                                if (!clicked) finishAi(token, "선택한 화면 요소를 클릭할 수 없었습니다.")
                                else scheduleAiNext(token, goal, stepNo, "#${step.index} '${item.label.take(30)}' 클릭", fp, snapshot.appPackage)
                            }
                        }
                    }
                }
                if (RiskPolicy.needsConfirmation(item.label)) {
                    requestApproval("AI가 '${snapshot.appPackage}' 앱에서 '${item.label.take(80)}'을(를) 누르려고 합니다. 승인이 필요한 작업입니다.", token, clickAction)
                } else clickAction()
            }
            is AiStep.ScrollDown, is AiStep.ScrollUp -> {
                val scrollNode = ScreenObserver.findScrollable(rootInActiveWindow)
                if (scrollNode == null) {
                    finishAi(token, "스크롤 가능한 영역이 없습니다."); return
                }
                val direction = if (step is AiStep.ScrollDown) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                    else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                if (!scrollNode.performAction(direction)) finishAi(token, "스크롤에 실패했습니다.")
                else scheduleAiNext(token, goal, stepNo, "스크롤", fp, snapshot.appPackage)
            }
            is AiStep.Back -> {
                // Back is allowed, but a new package or unexpected screen stops the loop.
                if (!performGlobalAction(GLOBAL_ACTION_BACK)) finishAi(token, "뒤로 가기 실패")
                else scheduleAiNext(token, goal, stepNo, "뒤로 가기", fp, snapshot.appPackage)
            }
        }
    }

    private fun scheduleAiNext(token: Int, goal: String, stepNo: Int, action: String, fp: String, originPackage: String) {
        if (token != sessionId) return
        result = "${stepNo + 1}단계 실행: $action / 화면 확인 중"
        handler.postDelayed({ aiNext(token, goal, stepNo + 1, action, fp, originPackage) }, 1100)
    }

    private fun isSensitivePackage(pkg: String): Boolean =
        Regex("bank|finance|wallet|pay|auth|secur|cert|password|credential", RegexOption.IGNORE_CASE)
            .containsMatchIn(pkg)

    private fun submit(raw: String) {
        stopCurrentTask()
        val token = sessionId
        removePanel()
        // Releasing the focusable overlay is essential before reading the target app.
        handler.postDelayed({
            if (token != sessionId) return@postDelayed
            runCommand(CommandParser.parse(raw), token)
        }, 450)
    }

    private fun announce(msg: String) { showPanel(msg) }

    private fun runCommand(cmd: Command, token: Int) {
        if (token != sessionId) return
        try {
            when (cmd) {
                is Command.ScreenRead -> announce(ScreenObserver.inspect(rootInActiveWindow).describe())
                is Command.Back -> {
                    announce(if (performGlobalAction(GLOBAL_ACTION_BACK)) "뒤로 가기 요청 완료" else "뒤로 가기 실패")
                }
                is Command.Home -> {
                    announce(if (performGlobalAction(GLOBAL_ACTION_HOME)) "홈 화면 요청 완료" else "홈 화면 이동 실패")
                }
                is Command.ScrollDown -> scroll(true)
                is Command.ScrollUp -> scroll(false)
                is Command.Find -> {
                    val found = ScreenObserver.findByLabel(rootInActiveWindow, cmd.label)
                    announce(if (found != null) "화면에서 '${cmd.label}' 항목을 찾았습니다." else "화면에서 '${cmd.label}'을 찾지 못했습니다.")
                }
                is Command.Click -> click(cmd.label, token)
                is Command.OpenApp -> openApp(cmd.name)
                is Command.Unsupported -> announce(cmd.reason)
            }
        } catch (e: Exception) {
            announce("실행 오류: ${e.javaClass.simpleName}: ${e.message ?: "알 수 없는 원인"}")
        }
    }

    private fun scroll(down: Boolean) {
        val node = ScreenObserver.findScrollable(rootInActiveWindow)
        if (node == null) {
            announce("스크롤 가능한 화면 요소를 찾지 못했습니다.")
            return
        }
        val action = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        val ok = node.performAction(action)
        announce(if (ok) "스크롤 조작을 요청했습니다. 실제 이동 여부를 확인하세요." else "스크롤 조작에 실패했습니다.")
    }

    private fun click(label: String, token: Int) {
        val snapshot = ScreenObserver.inspect(rootInActiveWindow)
        val found = ScreenObserver.findByLabel(rootInActiveWindow, label)
        if (found == null) {
            announce("'$label' 항목을 찾지 못했습니다. 먼저 '화면 읽어'로 실제 표시 이름을 확인하세요.")
            return
        }
        val actual = (found.text ?: found.contentDescription)?.toString().orEmpty()
        if (RiskPolicy.isForbidden(actual) || RiskPolicy.isForbidden(label)) {
            announce("민감한 인증 정보 관련 항목은 자동으로 클릭하지 않습니다. 직접 조작하세요.")
            return
        }
        val action = {
            // The target app and label must still match after the approval overlay closes.
            if (token == sessionId) {
                val current = ScreenObserver.inspect(rootInActiveWindow)
                if (current.appPackage != snapshot.appPackage) {
                    announce("화면이 바뀌어서 클릭을 취소했습니다.")
                } else {
                    val fresh = ScreenObserver.findByLabel(rootInActiveWindow, label)
                    if (fresh == null) announce("버튼이 사라져 클릭하지 않았습니다.")
                    else {
                        val freshLabel = (fresh.text ?: fresh.contentDescription)?.toString().orEmpty()
                        if (freshLabel != actual) announce("버튼 이름이 바뀌어 클릭을 중지했습니다.")
                        else {
                            val ok = performNodeClick(fresh)
                            announce(if (ok) "'$actual' 클릭을 요청했습니다. 결과를 확인하세요." else "'$actual' 클릭 실패: 클릭 가능한 요소가 없습니다.")
                        }
                    }
                }
            }
        }
        val sensitiveApp = Regex("bank|pay|wallet|finance|secur|auth", RegexOption.IGNORE_CASE)
            .containsMatchIn(snapshot.appPackage)
        if (sensitiveApp || RiskPolicy.needsConfirmation(actual) || RiskPolicy.needsConfirmation(label)) {
            requestApproval("'${snapshot.appPackage}' 앱의 '$actual' 항목을 누르려고 합니다. 실행할까요?", token, action)
        } else action()
    }

    private fun performNodeClick(node: AccessibilityNodeInfo): Boolean {
        var p: AccessibilityNodeInfo? = node
        var hops = 0
        while (p != null && hops < 5) {
            if (p.isVisibleToUser && p.isEnabled && p.isClickable) {
                return p.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            p = p.parent
            hops++
        }
        return false
    }

    private fun requestApproval(message: String, token: Int, action: () -> Unit) {
        removePanel()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(Color.rgb(57, 35, 34))
        }
        root.addView(uiText("중요 작업 승인", 18f))
        root.addView(uiText(message))
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val reject = Button(this).apply {
            text = "취소"
            setOnClickListener {
                stopCurrentTask()
                showPanel("사용자가 중요한 작업을 취소했습니다.")
            }
        }
        val approve = Button(this).apply {
            text = "승인하고 실행"
            setOnClickListener {
                removePanel()
                handler.postDelayed({ if (sessionId == token) action() }, 450)
            }
        }
        buttons.addView(reject, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(approve, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(buttons)
        val p = overlayParams(minOf(dp(340), resources.displayMetrics.widthPixels - dp(24)),
            WindowManager.LayoutParams.WRAP_CONTENT, Gravity.CENTER, true)
        try { windowManager.addView(root, p); panel = root }
        catch (_: Exception) { stopCurrentTask(); showPanel("승인 창 표시 실패. 작업을 중단했습니다.") }
    }

    private fun openApp(name: String) {
        if (name == "설정") {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            announce("설정 실행 요청 완료. 설정 화면에서 J 버튼으로 계속 조작하세요.")
            return
        }
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val matched = packageManager.queryIntentActivities(launcher, 0).firstOrNull {
            val label = it.loadLabel(packageManager).toString()
            label.equals(name, ignoreCase = true) || label.contains(name, ignoreCase = true)
        }
        if (matched == null) {
            announce("'$name' 앱을 설치된 실행 가능 앱 목록에서 찾지 못했습니다.")
            return
        }
        val pkg = matched.activityInfo.packageName
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) announce("'$name' 앱을 실행할 수 없습니다.")
        else {
            startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            announce("'$name' 실행 요청 완료. 화면 상태를 확인하세요.")
        }
    }
}
