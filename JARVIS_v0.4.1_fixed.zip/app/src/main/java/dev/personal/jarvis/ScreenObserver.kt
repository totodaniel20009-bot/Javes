package dev.personal.jarvis

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

data class VisibleItem(
    val label: String,
    val clickable: Boolean,
    val scrollable: Boolean,
    val enabled: Boolean,
    val bounds: Rect
)

data class ScreenSnapshot(val appPackage: String, val items: List<VisibleItem>) {
    fun fingerprint(): String = appPackage + ":" + items.take(80).joinToString("|") {
        "${it.label}:${it.bounds.left}:${it.bounds.top}"
    }
    fun describe(maxLines: Int = 34): String {
        return buildString {
            append("현재 앱: ").append(appPackage).append('\n')
            append("표시된 항목: ").append(items.size).append("개\n")
            items.take(maxLines).forEachIndexed { index, item ->
                append("#").append(index).append(" ").append(item.label.take(85))
                    .append(if (item.clickable) " [클릭 가능]" else "").append('\n')
            }
            if (items.isEmpty()) append("접근성으로 읽을 수 있는 항목이 없습니다.")
        }
    }
}

object ScreenObserver {
    private fun walk(root: AccessibilityNodeInfo?, visit: (AccessibilityNodeInfo) -> Boolean) {
        if (root == null) return
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var count = 0
        while (queue.isNotEmpty() && count++ < 350) {
            val node = queue.removeFirst()
            if (!node.isVisibleToUser || node.isPassword) continue
            if (!visit(node)) return
            for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it) }
        }
    }
    private fun label(node: AccessibilityNodeInfo): String =
        (node.text ?: node.contentDescription)?.toString()?.trim().orEmpty()

    private fun clickableWithParent(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var depth = 0
        while (current != null && depth++ < 5) {
            if (current.isEnabled && current.isClickable) return true
            current = current.parent
        }
        return false
    }

    fun inspect(root: AccessibilityNodeInfo?): ScreenSnapshot {
        if (root == null) return ScreenSnapshot("", emptyList())
        val items = ArrayList<VisibleItem>(90)
        walk(root) { node ->
            val str = label(node)
            if (str.isNotEmpty() && items.size < 120) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                items.add(VisibleItem(str.take(140), clickableWithParent(node), node.isScrollable, node.isEnabled, rect))
            }
            items.size < 120
        }
        return ScreenSnapshot(root.packageName?.toString().orEmpty(), items)
    }

    /** Re-finds the exact label and bounds at action time; never reuse a stale node handle. */
    fun resolveTarget(root: AccessibilityNodeInfo?, item: VisibleItem): AccessibilityNodeInfo? {
        var match: AccessibilityNodeInfo? = null
        walk(root) { node ->
            val rect = Rect()
            node.getBoundsInScreen(rect)
            if (node.isEnabled && label(node).take(140) == item.label && rect == item.bounds) {
                match = node
                return@walk false
            }
            true
        }
        return match
    }

    fun findByLabel(root: AccessibilityNodeInfo?, query: String): AccessibilityNodeInfo? {
        if (query.isBlank()) return null
        var exact: AccessibilityNodeInfo? = null
        var partial: AccessibilityNodeInfo? = null
        walk(root) { node ->
            val name = label(node)
            if (name.equals(query.trim(), ignoreCase = true)) { exact = node; false }
            else { if (partial == null && name.contains(query.trim(), ignoreCase = true)) partial = node; true }
        }
        return exact ?: partial
    }

    fun findScrollable(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var match: AccessibilityNodeInfo? = null
        walk(root) { node -> if (node.isScrollable) { match = node; false } else true }
        return match
    }
}
